import React from 'react'
import { Link } from 'react-router-dom'
import '../css/dashboard.css'
import image from '../assets/student.jpg'



function dashboard() {
  return (
    <>
        <div className="container_dashboard">
            <nav>
                <ul>
                    <li><Link className="links logo" to="/dashboard">
                    <img alt='' src={image}/>
                    <span className="nav-item">Sandra Dery-Kunzume</span>
                    </Link></li>
                    <li><Link className="links" to="/dashboard">
                    <i className="fas fa-menorah"></i>
                    <span className="nav-item">Course Overview</span>
                    </Link></li>
                    <li><Link className="links" to="/dashboard">
                    <i className="fas fa-comment"></i>
                    <span className="nav-item">Course Materials</span>
                    </Link></li>
                    <li><Link className="links" to="/dashboard">
                    <i className="fas fa-database"></i>
                    <span className="nav-item">Courses</span>
                    </Link></li>
                    <li><Link className="links" to="/dashboard">
                    <i className="fas fa-chart-bar"></i>
                    <span className="nav-item">Announcements</span>
                    </Link></li>
                    <li><Link className="links" to="/dashboard">
                    <i className="fas fa-cog"></i>
                    <span className="nav-item">Account & Settings</span>
                    </Link></li>

                    <li><Link className="links logout" to="/login">
                    <i className="fas fa-sign-out-alt"></i>
                    <span className="nav-item">Log out</span>
                    </Link></li>
                </ul>
            </nav>


            <section className="main">
                <div className="main-top">
                    <div>
                        <h1>School of Engineering Sciences</h1>
                        <i className="fas fa-user-cog"></i>
                    </div>
                    <div className='logins'>
                        <Link className="links" to='/login'>LOGIN</Link>
                        <Link className="links" to='/register'>SignUp</Link>
                    </div>
                    
                </div>
            <div className="users">
                <div className="card">
                
                <h4>Assignments Due</h4>
                
                <button>View</button>
                </div>
                <div className="card">
                
                <h4>Assignments Completed</h4>
                
                <button>View</button>
                </div>
                <div className="card">
                
                <h4>Schedules</h4>
                
                
                <button>View</button>
                </div>
                <div className="card">
                
                <h4>Grade Book</h4>
                
                
                <button>View</button>
                </div>
            </div>

            <section className="attendance">
                <div className="attendance-list">
                <h1>Courses Timetable
                </h1>
                <table className="table">
                    <thead>
                    <tr>
                        <th>Course ID</th>
                        <th>Course Name</th>
                        <th>Venue</th>
                        <th>Day</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Details</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>CPEN 201</td>
                        <td>software Engineering</td>
                        <td>SF-F1</td>
                        <td>Monday</td>
                        <td>8:30AM</td>
                        <td>10:30AM</td>
                        <td><button>View</button></td>
                    </tr>
                    <tr className="active">
                        <td>CPEN 212</td>
                        <td>Digital Circuit</td>
                        <td>Electronics Lab</td>
                        <td>FridayS</td>
                        <td>3:30PM</td>
                        <td>5:30PM</td>
                        <td><button>View</button></td>
                    </tr>
                    <tr>
                        <td>CPEN 213</td>
                        <td>LInear Circuits</td>
                        <td>SF-F2</td>
                        <td>Wednesday</td>
                        <td>9:30AM</td>
                        <td>11:30PM</td>
                        <td><button>View</button></td>
                    </tr>
                    <tr>
                        <td>SENG 204</td>
                        <td>Differential Equation</td>
                        <td>NNB2</td>
                        <td>Thursdays</td>
                        <td>5:30PM</td>
                        <td>7:30PM</td>
                        <td><button>View</button></td>
                    </tr>
                    <tr >
                        <td>CPEN 225</td>
                        <td>Data Communications</td>
                        <td>HUawei Lab</td>
                        <td>Tuesday</td>
                        <td>7:30AM</td>
                        <td>9:30AM</td>
                        <td><button>View</button></td>
                    </tr>
                    <tr >
                        <td>SENG 206</td>
                        <td>Programming for Engineering</td>
                        <td>EW-S2</td>
                        <td>Fridays</td>
                        <td>12:30AM</td>
                        <td>2:30PM</td>
                        <td><button>View</button></td>
                    </tr>
                    </tbody>
                </table>
                </div>
            </section>
            </section>
      </div>
    
    </>
  )
}

export default dashboard