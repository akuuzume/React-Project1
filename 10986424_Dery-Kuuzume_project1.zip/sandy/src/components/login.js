import React from 'react'
import '../css/login.css'
import { Link } from 'react-router-dom'

function login() {
  return (
    <>
        <div className='dash'> 
          <h1 className='welcome'>Welcome</h1>
          <div className='select'>
            <h4 className='h4'><Link className='login_links' to='/dashboard'>Dashboard</Link></h4>
            <h4 className='h4'><Link className='login_links' to='/register'>Register</Link></h4>
          </div>
          
        </div>
        
        <div className='bigger'>
          <div className="container">
              <div>
                  <p className='login_text'>Login</p>
                  <form>
                      <input className='input_type' type="text" placeholder="Username" required/>
                      <input className='input_type' type="password" placeholder="Password" required/>
                      <input className='submit_btn' type="submit" value="Login"/>
                  </form>
                  <p className='ask'>Do not have an account?<Link to="/register">Sign Up here</Link></p>
              </div>
            
          </div>
        </div>
    </>
  )
}

export default login